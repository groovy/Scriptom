TLBINF32.DLL ships with Visual Basic 6 and is not installed by default on Windows.

To register, copy to the \System32 folder and run from the command line:
	regsvr32 C:\Windows\System32\TLBINF32.DLL

This copy is a reference copy and is not meant for general distribution with any Groovy package.